package net.shoreline.client.api.event;

public enum EventStage {
    PRE,
    POST
}
