package net.shoreline.client.impl.event.network;

import net.shoreline.client.api.event.Event;

public class PlayerTickEvent extends Event {

}
