package net.shoreline.client.impl.event.world;

import net.shoreline.client.api.event.Cancelable;
import net.shoreline.client.api.event.Event;

@Cancelable
public class BlindnessEvent extends Event {

}
