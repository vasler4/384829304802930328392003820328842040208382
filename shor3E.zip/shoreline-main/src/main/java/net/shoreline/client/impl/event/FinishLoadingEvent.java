package net.shoreline.client.impl.event;

import net.shoreline.client.api.event.Event;

public class FinishLoadingEvent extends Event {
}
