package net.shoreline.client.api.account.msa.model;

/**
 * @author xgraza
 * @since 01/14/24
 */
public record MinecraftProfile(String username, String id)
{ }
