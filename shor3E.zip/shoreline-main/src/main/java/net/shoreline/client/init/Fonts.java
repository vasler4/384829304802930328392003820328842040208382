package net.shoreline.client.init;

import net.shoreline.client.font.CustomTextRenderer;

public class Fonts {
    //
    public static final CustomTextRenderer VANILLA = new CustomTextRenderer();
}
