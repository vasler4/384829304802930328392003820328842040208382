package net.shoreline.client.impl.imixin;

public interface IClientPlayerEntity {

    float getLastSpoofedYaw();
    float getLastSpoofedPitch();

}
