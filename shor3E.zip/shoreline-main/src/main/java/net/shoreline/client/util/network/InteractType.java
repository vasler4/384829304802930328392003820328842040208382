package net.shoreline.client.util.network;

public enum InteractType {
    INTERACT,
    ATTACK,
    INTERACT_AT
}
