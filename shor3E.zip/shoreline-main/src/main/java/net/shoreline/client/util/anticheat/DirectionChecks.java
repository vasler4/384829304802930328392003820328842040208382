package net.shoreline.client.util.anticheat;

import net.shoreline.client.util.Globals;

/**
 * @author linus
 * @since 1.0
 */
public class DirectionChecks implements Globals {

}
