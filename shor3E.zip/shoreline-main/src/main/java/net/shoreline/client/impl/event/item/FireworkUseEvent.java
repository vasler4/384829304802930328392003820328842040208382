package net.shoreline.client.impl.event.item;

import net.shoreline.client.api.event.Event;

public class FireworkUseEvent extends Event {

}
