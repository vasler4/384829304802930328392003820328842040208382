package net.shoreline.client.impl.event.keyboard;

import net.shoreline.client.api.event.Cancelable;
import net.shoreline.client.api.event.Event;

@Cancelable
public class KeyboardTickEvent extends Event {
    /*
    private float movementForward;
    private float movementSideways;

    public KeyboardTickEvent(float movementForward, float movementSideways)
    {
        this.movementForward = movementForward;
        this.movementSideways = movementSideways;
    }

    public float getMovementForward()
    {
        return movementForward;
    }

    public float getMovementSideways()
    {
        return movementSideways;
    }

    public void setMovementForward(float movementForward)
    {
        this.movementForward = movementForward;
    }

    public void setMovementSideways(float movementSideways)
    {
        this.movementSideways = movementSideways;
    }

     */
}
