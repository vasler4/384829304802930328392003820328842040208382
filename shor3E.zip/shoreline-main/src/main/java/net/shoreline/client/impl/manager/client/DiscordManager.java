package net.shoreline.client.impl.manager.client;

/**
 * @author linus
 * @since 1.0
 */
public class DiscordManager {
    public void startRPC() {

    }
}
