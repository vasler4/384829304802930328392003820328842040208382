package net.shoreline.client.util.math.timer;

public class HashTimer {

}
