package net.shoreline.client.api.social;

public enum SocialRelation {
    FRIEND
}
