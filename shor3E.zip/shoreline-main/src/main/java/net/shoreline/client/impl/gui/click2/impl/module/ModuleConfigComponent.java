package net.shoreline.client.impl.gui.click2.impl.module;

public class ModuleConfigComponent {
}
